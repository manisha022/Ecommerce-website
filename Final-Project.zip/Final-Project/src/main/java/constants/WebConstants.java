package constants;

public class WebConstants {
	// Parameters
	public static final String USER_AUTH_TOKEN = "AUTH_TOKEN";
	public static final String PROD_FILE = "file";
	public static final String PROD_DESC = "description";
	public static final String PROD_NAME = "productname";
	public static final String PROD_PRICE = "price";
	public static final String PROD_QUANITY = "quantity";
	public static final String PROD_ID = "productId";

	// Domains
	public static final String ALLOWED_URL = "http://localhost:4200";

}