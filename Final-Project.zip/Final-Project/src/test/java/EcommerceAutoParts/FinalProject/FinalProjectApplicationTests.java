package EcommerceAutoParts.FinalProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
